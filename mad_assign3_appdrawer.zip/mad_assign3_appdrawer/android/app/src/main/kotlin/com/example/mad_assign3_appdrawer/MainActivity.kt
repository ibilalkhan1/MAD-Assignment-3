package com.example.mad_assign3_appdrawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

import 'package:flutter/material.dart';
import 'about.dart';
import 'contact.dart';
import 'services.dart';
import 'feedback.dart';

class TopNavScreen extends StatelessWidget {
  const TopNavScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Top Navigation Bar'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'About'),
              Tab(text: 'Contact'),
              Tab(text: 'Services'),
              Tab(text: 'Feedback'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            AboutScreen(),
            ContactScreen(),
            ServicesScreen(),
            FeedbackScreen(),
          ],
        ),
      ),
    );
  }
}
